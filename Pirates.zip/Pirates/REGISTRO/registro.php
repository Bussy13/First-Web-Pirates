<?php

require('../LOGIN/conexion.php');

// Parte de insertar

// isset para validar, en este caso validara enviar para ejecutar ese if

  if (isset($_POST['enviar'])) 
  {
    $user = $_POST["usuario"];
    $clave = $_POST["contraseña"];
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $telefono = $_POST["telefono"];
    $sexo = $_POST["sexo"];


//mysqli_query ejecutaremos la query siendo la primera para la conexion y 
//la otra para insertar los registros
//Primero debera comprobar si existe el usuario 
//la segunda sería para el correo 
//la tercera para el telefono

$queryusuario = mysqli_query($conn, "SELECT id from clientes where usuario = '$user'");

$querycorreo = mysqli_query($conn, "SELECT id from clientes where correo = '$correo'");

$querytelefono = mysqli_query($conn, "SELECT id from clientes where telefono = '$telefono'");

$validacion_usuario =mysqli_num_rows($queryusuario);

$validacion_correo =mysqli_num_rows($querycorreo);

$validacion_telefono =mysqli_num_rows($querytelefono);

//Validamos con un if, si nos da el resultado del select igual a 1 entonces significar que ya existe el usuario.

if ($validacion_usuario == 1)

{
 
echo"<script> alert('Usuario ya registrado, por favor intentelo de nuevo.');window.location= 'registro.html' </script>";

}


//En este if nos validara si existe ese correo

if ($validacion_correo == 1)

{
 
echo"<script> alert('Correo ya utilizado, por favor use otra dirección.');window.location= 'registro.html' </script>";

}

//En este if nos validara si existe ese telefono

if ($validacion_telefono == 1)

{
 
echo"<script> alert('Telefono ya registrado, por favor facilitenos otro numero de contacto.');window.location= 'registro.html' </script>";

}

// La variable insertarDatos nos permitara ejecutar la insercción en la tabla clientes

$insertarDatos = "INSERT INTO clientes VALUES('$user', '$clave','$nombre','$correo','$telefono', '$sexo', null)";
   
//CLAVE!! Aqui nosotros podemos ver el operador and que nos permite agregar condiciones para ejecutar el insert.
//Escribiremos todas las variables para que sean 0 y así comprobar que no coinicide ningun  registro


if ($validacion_usuario == 0 and $validacion_correo == 0 and $validacion_telefono == 0)
{

  
    $ejecutarInsertar = mysqli_query($conn, $insertarDatos);

    echo "<script> alert('Usuario registrado.');window.location= '../LOGIN/login.html'</script>";
     



}

 
    
}
