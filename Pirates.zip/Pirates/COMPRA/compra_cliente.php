<?php
// Inciamos Sesion

session_start(); 

?>
<!DOCTYPE html>
<html lang="en">
<head>6
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Link Boostrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Link mi CSS -->
       <link rel="stylesheet" href="compra.css">
    <!-- Icono -->
    <link rel="icon" href="../Imagenes/favicon.jpg" type="image/x-icon">
       <title>The Pirates</title>
</head>
<body class="bg-dark">

       <div class="container">
              <a href="../Home/home.html"><img src="../Imagenes/1.png" class="img-fluid h-3 mt-5"></a>
       </div>
       <h1 class="rev-block ancho">
    <span>GRACIAS POR LA COMPRA</span>
  </h1>
  <h1 class="rev-block mt-5" id="onemore">
    <span class="text-danger fw-bold"><?php echo $_SESSION["usuario"]; ?></span>
  </h1>

 
</body>
</html>


