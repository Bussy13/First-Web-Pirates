<?php

//Inlcuir el archivo de conexion con la Base de datos
include ("../LOGIN/conexion.php");
include ("../REGISTRO/registro.php");

//Creo dos variables para el usario y contraseña del name="" en el form
$users = $_POST["usuario"];
$clave  = $_POST["contraseña"];

//Para iniciar sesión

//Declaramos dos variables y  mysqli_query nos permite ejecutar la query en la base de datos

$verificacion_contraseña = password_verify ($encriptar_contraseña, $clave);

$trabajadores = mysqli_query($conn, "SELECT id FROM empleados WHERE nombre ='$users'");

$clientes = mysqli_query($conn, "SELECT id FROM clientes WHERE usuario ='$users'");

$facturacion_clientes = 




//Declaramos otras dos variables mysqli_num_rows (variable de la query) nos permite mirar los registros de la tabla

$nr 		= mysqli_num_rows($clientes);  

$ns         = mysqli_num_rows($trabajadores);

	
//If la varible ns / nr es igual a 1 nos permitira logearnos, ya que habra un registro tambien valdria poner if ($nr > 0)  

if ($ns == 1) 

	{ 
	echo "<script> alert('Trabajador');window.location= 'compra_trabajador.php'</script>";

	}

elseif ($nr == 1)
	
{ 
	echo "<script> alert('Cliente');window.location= 'compra_cliente.php'</script>";

	}

else

{
	echo "<script> alert('Usuario o contraseña incorrecto.');window.location= 'compra_login.html' </script>";
	}



	$direccion = $_POST("direccion_facturacion");

//iniciamos sesión

session_start();

$_SESSION["usuario"] = $users;





?>

