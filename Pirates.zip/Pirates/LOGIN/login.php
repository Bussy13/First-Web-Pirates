<?php

//Inlcuir el archivo de conexion con la Base de datos
include ("conexion.php");

//Creo dos variables para el usario y contraseña del name="" en el form
$users = $_POST["usuario"];
$claves  = $_POST["contraseña"];

//Para iniciar sesión

//Declaramos dos variables y  mysqli_query nos permite ejecutar la query en la base de datos

$trabajadores = mysqli_query($conn, "SELECT id FROM empleados WHERE nombre ='$users' and contraseña = '$claves'");

$clientes = mysqli_query($conn, "SELECT id FROM clientes WHERE usuario ='$users' and contraseña = '$claves'");


//Declaramos otras dos variables mysqli_num_rows (variable de la query) nos permite mirar los registros de la tabla

$nr 		= mysqli_num_rows($clientes);  

$ns         = mysqli_num_rows($trabajadores);
	
//If la varible ns / nr es igual a 1 nos permitira logearnos, ya que habra un registro tambien valdria poner if ($nr > 0)  

if ($ns == 1)  
	{ 
	echo "<script> alert('A trabajar!! Suerte.');window.location= 'trabajadores.html' </script>";

	}
elseif ($nr == 1)
	
{ 
	echo "<script> alert('Bienvenido de nuevo, un placer volver a verte.');window.location= 'cliente.html' </script>";

	}

else

{
	echo "<script> alert('Usuario o contraseña incorrecto.');window.location= 'login.html' </script>";
	}

?>

