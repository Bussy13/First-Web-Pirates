<?php

// Inciamos Sesion

session_start(); 



?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Link Boostrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Link cdn.js -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css" integrity="sha512-UTNP5BXLIptsaj5WdKFrkFov94lDx+eBvbKyoe1YAfjeRPC+gT5kyZ10kOHCfNZqEui1sxmqvodNUx3KbuYI/A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css" integrity="sha512-OTcub78R3msOCtY3Tc6FzeDJ8N9qvQn1Ph49ou13xgA9VsH9+LRxoFU6EqLhW4+PKRfU+/HReXmSZXHEkpYoOA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Transiciones Libreria Imagens -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Readex+Pro&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- Personal CSS -->
    <link rel="stylesheet" href="./equipamentos.css">
    <!-- My Icon -->
    <link rel="icon" href="../Imagenes/favicon.jpg" type="image/x-icon">
    <title>The Pirates</title>
</head>

<body class="bg-fondo">
    <!-- Menu -->
    <header>
        <input class="menu-icon" type="checkbox" id="menu-icon" name="menu-icon" />
        <label for="menu-icon"></label>
        <nav class="nav">
            <ul class="pt-5">
                <li><img src="../Imagenes/1.png" class="img-fluid h-8 pb-3"></li>
                <li><a href="../index.php">Panel de control</a></li>
                <li><a href="../Home/home.php">Home</a></li>
                <li><a href="equipamentos.html" class="site">Tienda</a></li>
                <li><a href="../FOTOS/">Fotos</a></li>
                <li><a href="../CONTACTO/contacto.html">Contacto</a></li>
            </ul>
        </nav>
    </header>
    <!-- inicio -->
    <section>
        <div class="container-fluid">
            <div class="container mt-4 pt-4 w-50" data-aos="flip-up" data-aos-duration="3000">
                <p class="text-light fw-bold text-center h2 text-decoration-underline titulos bg">Hora de equiparse pirata
            </div>
        </div>
    </section>
    <!-- Carrosuel con Productos -->
    <main>
        <div class="owl-container mt-5 px-5">
            <div class="container-fluid pt-2 ms-5">
                <div class="owl-carousel owl-theme">
                    <div class="item">
                        <div class="card" style="width: 18rem;">
                            <img src="../Imagenes/garfio.jpg" class="card-img-top">
                            <div class="card-body">
                                <p class="card-title fw-bold text-center h5 titulos">¿Te echo una mano?</p>
                                <p class="card-text">Perfecto para quien le falte una mano</p>
                                <div class="container">
                                    <div class="row">
                                        <div class="col-6">
                                            <button type="button" class="btn btn-outline-info" data-bs-toggle="modal" data-bs-target="#garfio">
                                                Ampliame
                                            </button>
                                        </div>
                                        <div class="col-6">
                                            <a href="../GARFIO/garfio.php">
                                                <button type="button" class="btn btn-outline-primary">
                                                    Detalles
                                                </button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Espada -->
                    <div class="item">
                        <div class="card" style="width: 18rem;">
                            <img src="../Imagenes/espada.jpg" class="card-img-top">
                            <div class="card-body">
                                <p class="card-title fw-bold text-center h5 titulos">Viuda Negra</p>
                                <p class="card-text">No tiene amigos, bueno quizas...</p>
                                <div class="container">
                                    <div class="row">
                                        <div class="col-6 pt-4">
                                            <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#espada">
                                                Ampliame
                                            </button>
                                        </div>
                                        <div class="col-6 pt-4">
                                            <a href="../ESPADA/espada.php">
                                                <button type="button" class="btn btn-outline-danger">
                                                    Detalles
                                                </button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Sombrero -->
                    <div class="item">
                        <div class="card" style="width: 18rem;">
                            <img src="../Imagenes/sombrero.jpg" class="card-img-top">
                            <div class="card-body">
                                <p class="card-title fw-bold text-center h5 titulos">Gran Capitan</p>
                                <p class="card-text">A un gran Pirata no le puede faltar</p>
                                <div class="container">
                                    <div class="row">
                                        <div class="col-6 pt-4">
                                            <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#sombrero">
                                                Ampliame
                                            </button>
                                        </div>
                                        <div class="col-6 pt-4">
                                            <a href="../SOMBRERO/sombrero.php">
                                                <button type="button" class="btn btn-outline-success">
                                                    Detalles
                                                </button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Disfraz -->
                    <div class="item">
                        <div class="card" style="width: 18rem;">
                            <img src="../Imagenes/disfraz.jpg" class="card-img-top pt-4">
                            <div class="card-body">
                                <p class="card-title fw-bold text-center h5 titulos">Barba Roja</p>
                                <p class="card-text">Vistete como el mas temible pirata de todos los oceanos</p>
                                <div class="container">
                                    <div class="row">
                                        <div class="col-6">
                                            <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#disfraz">
                                                Ampliame
                                            </button>
                                        </div>
                                        <div class="col-6">
                                            <a href="../DISFRAZ/disfraz.php">
                                                <button type="button" class="btn btn-outline-info">
                                                    Detalles
                                                </button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- Relleno parte de abajo  -->
    <section>
        <div class="container pt-5 mt-5"></div>
    </section>
    <!-- Modal Espada -->
    <section>
        <div class="modal fade mt-5 pt-5" id="espada" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="false">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <img src="../Imagenes/espada.jpg" class="portfolio portfolio2">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Modal Garfio -->
    <section>
        <div class="modal fade mt-5 pt-5" id="garfio" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="false">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <img src="../Imagenes/garfio.jpg" class="portfolio portfolio2">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Modal Disfraz -->
    <section>
        <div class="modal fade mt-5 pt-5" id="disfraz" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="false">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <img src="../Imagenes/disfraz.jpg" class="portfolio portfolio3">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Modal Sombrero -->
    <section>
        <div class="modal fade mt-5 pt-5" id="sombrero" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="false">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <img src="../Imagenes/sombrero.jpg" class="portfolio portfolio2">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- LINKS -->
    <!-- libreria Java -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Libreria AOS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <!-- Link para lo del menu del color -->
    <script src="./Bootstrap 5 - Transparent Navbar_files/bootstrap.bundle.min.js"></script>
    <!-- SCRIPTS -->
    <!-- Owl Carrousel -->
    <script type="text/javascript">
    $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 0,
        padding: 0,
        autoplay: true,
        autoplayTimeout: 6000,
        responsive: {
            0: {
                items: 1
            },

            600: {
                items: 2
            },

            1000: {
                items: 3
            }
        }
    })
    </script>
    <!-- AOS -->
    <script>
    AOS.init();
    </script>
</body>

</html>