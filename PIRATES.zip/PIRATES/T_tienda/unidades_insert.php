<?php

require('../LOGIN/conexion.php');

// Sombrero

if(isset($_POST['enviar_sombrero'])){
  
  $sombrero = $_POST["sombrero"];

  $querysombrero = mysqli_query($conn, "SELECT SUM(Unidades + $sombrero) as 'Unidades' from productos WHERE Nombre_producto = 'Sombrero'");

  $a_sombrero =$querysombrero ->fetch_array()['Unidades'] ?? '';
    
    $update_sombrero = mysqli_query($conn, "UPDATE productos SET Unidades = $a_sombrero where Nombre_producto = 'Sombrero'");
    echo "<script> alert('Añadido correctamente a la Base de datos');window.location= 'almacen.php' </script>" ; 

}

     // Disfraz


if(isset($_POST['enviar_disfraz'])){

  $disfraz = $_POST["disfraz"];
  
 $querydisfraz = mysqli_query($conn, "SELECT SUM(Unidades + $disfraz) as 'Unidades' from productos WHERE Nombre_producto = 'Disfraz'");

 $a_disfraz =$querydisfraz ->fetch_array()['Unidades'] ?? '';
   
$update_disfraz = mysqli_query($conn, "UPDATE productos SET Unidades = $a_disfraz where Nombre_producto = 'Disfraz'");

echo "<script> alert('Añadido correctamente a la Base de datos');window.location= 'almacen.php' </script>" ; 

}

 // Espada

 if(isset($_POST['enviar_espada'])){

$espada = $_POST["espada"];

 $queryespada = mysqli_query($conn, "SELECT SUM(Unidades + $espada) as 'Unidades' from productos WHERE Nombre_producto = 'Espada'");

 $a_espada =$queryespada ->fetch_array()['Unidades'] ?? '';
   
   $udpate_espada = mysqli_query($conn, "UPDATE productos SET Unidades = $a_espada where Nombre_producto = 'Espada'");
     
   echo "<script> alert('Añadido correctamente a la Base de datos');window.location= 'almacen.php' </script>" ; 

  }
 

  // Garfio

  if(isset($_POST['enviar_garfio'])){

    $garfio = $_POST["garfio"];

    $querygarfio = mysqli_query($conn, "SELECT SUM(Unidades + $garfio) as 'Unidades' from productos WHERE Nombre_producto = 'Garfio'");

    $a_garfio =$querygarfio ->fetch_array()['Unidades'] ?? '';
      
      $update_garfio = mysqli_query($conn, "UPDATE productos SET Unidades = $a_garfio where Nombre_producto = 'Garfio'");
     
     
      echo "<script> alert('Añadido correctamente a la Base de datos');window.location= 'almacen.php' </script>" ;  
    
  
  }

   else{

echo "<script> alert('Algo salio mal');window.location= 'unidades.php' </script>" ;  
    

   }

?>