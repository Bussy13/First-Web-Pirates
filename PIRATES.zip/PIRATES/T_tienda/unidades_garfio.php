<?php

require('../LOGIN/conexion.php');

$garfio = $_POST["garfio"];

    // Garfio

 $querygarfio = mysqli_query($conn, "SELECT SUM(Unidades + $garfio) as 'Unidades' from productos WHERE Nombre_producto = 'Garfio'");

 $a_garfio =$querygarfio ->fetch_array()['Unidades'] ?? '';
   
   $update_garfio = mysqli_query($conn, "UPDATE productos SET Unidades = $a_garfio where Nombre_producto = 'Garfio'");


    echo "<script> alert('Añadido correctamente a la Base de datos');window.location= 'almacen.php' </script>" ;  




    if(!$conn){
        echo"Error en la conexion con el servidor, no se inserto";
        }  


?>