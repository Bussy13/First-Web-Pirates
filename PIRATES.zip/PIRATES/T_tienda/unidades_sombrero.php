<?php

require('../LOGIN/conexion.php');




$sombrero = $_POST["sombrero"];



// Sombrero

 $querysombrero = mysqli_query($conn, "SELECT SUM(Unidades + $sombrero) as 'Unidades' from productos WHERE Nombre_producto = 'Sombrero'");

  $a_sombrero =$querysombrero ->fetch_array()['Unidades'] ?? '';
    
    $update_sombrero = mysqli_query($conn, "UPDATE productos SET Unidades = $a_sombrero where Nombre_producto = 'Sombrero'");

   
   
    

    echo "<script> alert('Añadido correctamente a la Base de datos');window.location= 'almacen.php' </script>" ;  




    if(!$conn){
        echo"Error en la conexion con el servidor, no se inserto";
        }  


?>