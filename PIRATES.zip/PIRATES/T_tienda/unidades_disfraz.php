<?php

require('../LOGIN/conexion.php');



$disfraz = $_POST["disfraz"];


     // Disfraz

 $querydisfraz = mysqli_query($conn, "SELECT SUM(Unidades + $disfraz) as 'Unidades' from productos WHERE Nombre_producto = 'Disfraz'");

 $a_disfraz =$querydisfraz ->fetch_array()['Unidades'] ?? '';
   
$update_disfraz = mysqli_query($conn, "UPDATE productos SET Unidades = $a_disfraz where Nombre_producto = 'DisfrazDisfraz'");

   
   

    echo "<script> alert('Añadido correctamente a la Base de datos');window.location= 'almacen.php' </script>" ;  




    if(!$conn){
        echo"Error en la conexion con el servidor, no se inserto";
        }  


?>