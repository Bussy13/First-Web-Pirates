<?php

// Inciamos Sesion
require('../LOGIN/conexion.php');


session_start(); 

if (!isset($_SESSION["usuario"])) {
    
    echo "<script> alert('Su sesion expiro');window.location= '../index.html' </script>";
}

$mostrar_Sombrero = mysqli_query($conn, "SELECT Unidades FROM productos where Nombre_producto='Sombrero'");

$mostrar_espada =  mysqli_query($conn, "SELECT Unidades FROM productos where Nombre_producto='Espada'");

$mostrar_disfraz =  mysqli_query($conn, "SELECT Unidades FROM productos where Nombre_producto='Disfraz'");

$mostrar_garfio =  mysqli_query($conn, "SELECT Unidades FROM productos where Nombre_producto='Garfio'");



$unidad_sombrero =$mostrar_Sombrero ->fetch_array()['Unidades'] ?? '';

$unidad_espada =$mostrar_espada->fetch_array()['Unidades'] ?? '';

$unidad_disfraz =$mostrar_disfraz->fetch_array()['Unidades'] ?? '';

$unidad_garfio =$mostrar_garfio->fetch_array()['Unidades'] ?? '';



$precio_Sombrero = mysqli_query($conn, "SELECT precios FROM productos where Nombre_producto='Sombrero'");

$precio_espada = mysqli_query($conn, "SELECT precios FROM productos where Nombre_producto='Espada'");

$precio_disfraz= mysqli_query($conn, "SELECT precios FROM productos where Nombre_producto='Disfraz'");

$precio_garfio= mysqli_query($conn, "SELECT precios FROM productos where Nombre_producto='Garfio'");

$p_sombrero =$precio_Sombrero->fetch_array()['precios'] ?? '';

$p_espada =$precio_espada->fetch_array()['precios'] ?? '';

$p_disfraz =$precio_disfraz->fetch_array()['precios'] ?? '';

$p_garfio =$precio_garfio->fetch_array()['precios'] ?? '';

?>



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Link Boostrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Links Iconos -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <!-- Link cdn.js -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css" integrity="sha512-UTNP5BXLIptsaj5WdKFrkFov94lDx+eBvbKyoe1YAfjeRPC+gT5kyZ10kOHCfNZqEui1sxmqvodNUx3KbuYI/A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css" integrity="sha512-OTcub78R3msOCtY3Tc6FzeDJ8N9qvQn1Ph49ou13xgA9VsH9+LRxoFU6EqLhW4+PKRfU+/HReXmSZXHEkpYoOA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Transiciones Libreria Imagens -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Readex+Pro&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- Personal CSS -->
    <link rel="stylesheet" href="unidades.css">
    <!-- My Icon -->
    <link rel="icon" href="../Imagenes/favicon.jpg" type="image/x-icon">
    <title>The Pirates</title>
</head>

<body class="bg-fondo">
    <!-- inicio -->
    <header>
                <!-- Inicio de log out -->
                <div class="container pt-5">
        <div class="dropdown">
  <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
  <p class="text-light"><img src="../Imagenes/usuario.png" class="limite"><?php echo $_SESSION["usuario"]; ?></p>
  </button>
  <ul class="dropdown-menu">
  <li><a class="dropdown-item" href="../T_tienda/t_tienda.php">Panel de control</a></li>
 <li><a class="dropdown-item" href="../CERRAR/cerrar.php">Cerrar sesion</a></li>
  </ul>
</div>
  <!-- Fin de log out -->
        </div>
        <div class="container-fluid">
<div class="container bg-azul d-flex justify-content-center pt-2">
<h2 class="fst-italic fw-bold text-light">Almacen</h2>
<form action="unidades_insert.php" method="post">
</div>
<div class="container">
    <div class="row">
        <!-- Sombrero -->
        <div class="col-lg-3 bg-light pt-4">
<div class=" d-flex justify-content-center">
<h4 class="fw-bold text-danger">Sombrero</h4>
</div>
<div class="container-fluid  d-flex justify-content-center pt-3">  
        <h5 class="fw-bold text-success">
        <?php echo $unidad_sombrero ?>
</h5>
        </div>
</div>
        <!-- Garfio -->
        <div class="col-lg-3 bg-light  pt-4">
<div class=" d-flex justify-content-center">
<h4 class="fw-bold text-danger">Garfio</h4>
</div>
<div class="container d-flex justify-content-center pt-3">  
        <h5 class="fw-bold text-success">
        <?php echo $unidad_garfio ?>
</h5>
        </div>
</div>
        <!-- Disfraz -->
        <div class="col-lg-3 bg-light  pt-4">
<div class=" d-flex justify-content-center">
<h4 class="fw-bold text-danger">Disfraz</h4>
</div>
<div class="container d-flex justify-content-center pt-3">  
        <h5 class="fw-bold text-success">
        <?php echo $unidad_disfraz ?>
</h5>
        </div>
</div>
        <!-- Espada -->
        <div class="col-lg-3 bg-light  pt-4">
<div class=" d-flex justify-content-center">
<h4 class="fw-bold text-danger">Espada</h4>
</div>
<div class="container d-flex justify-content-center pt-3">  
        <h5 class="fw-bold text-success">
        <?php echo $unidad_espada ?>
</h5>
</div>
</div>
        </div>
        <!-- Espaciado -->
        <div class="container mt-5"></div>
        <!-- Parte de precios -->
<div class="container-fluid bg-azul d-flex justify-content-center pt-2">
<h2 class="fst-italic fw-bold text-light">Precios</h5>
</div>
    <div class="row">
        <!-- Sombrero -->
        <div class="col-lg-3 bg-light pt-4">
<div class=" d-flex justify-content-center">
<h4 class="fw-bold text-danger">Sombrero</h4>
</div>
<div class="container-fluid  d-flex justify-content-center pt-3">  
        <h5 class="fw-bold text-success">
        <?php echo $p_sombrero ?>
</h5>
        </div>
</div>
        <!-- Garfio -->
        <div class="col-lg-3 bg-light  pt-4">
<div class=" d-flex justify-content-center">
<h4 class="fw-bold text-danger">Garfio</h4>
</div>
<div class="container d-flex justify-content-center pt-3">  
        <h5 class="fw-bold text-success">
        <?php echo $p_garfio ?>
</h5>
        </div>
</div>
        <!-- Disfraz -->
        <div class="col-lg-3 bg-light  pt-4">
<div class=" d-flex justify-content-center">
<h4 class="fw-bold text-danger">Disfraz</h4>
</div>
<div class="container d-flex justify-content-center pt-3">  
        <h5 class="fw-bold text-success">
        <?php echo $p_disfraz ?>
</h5>
        </div>
</div>
        <!-- Espada -->
        <div class="col-lg-3 bg-light  pt-4">
<div class=" d-flex justify-content-center">
<h4 class="fw-bold text-danger">Espada</h4>
</div>
<div class="container d-flex justify-content-center pt-3">  
        <h5 class="fw-bold text-success">
        <?php echo $p_espada ?>
</h5>
</div>
</div>
        </div>
    <!-- LINKS [Parte de Java]-->
    <!-- libreria Java -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Libreria AOS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <!-- Link para lo del menu del color -->
    <script src="./Bootstrap 5 - Transparent Navbar_files/bootstrap.bundle.min.js"></script>
</body>

</html>