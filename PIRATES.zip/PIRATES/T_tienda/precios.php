<?php

require('../LOGIN/conexion.php');

// Sombrero

if(isset($_POST['precio1'])){
  
  $sombrero = $_POST["sombrero"];
    
    $update_sombrero = mysqli_query($conn, "UPDATE productos SET precios = '$sombrero' where Nombre_producto = 'Sombrero'");

    echo "<script> alert('Actualizado correctamente a la Base de datos');window.location= 'almacen.php' </script>" ; 


}

     // Disfraz


if(isset($_POST['precio3'])){

  $disfraz = $_POST["disfraz"];
   
$update_disfraz = mysqli_query($conn, "UPDATE productos SET precios = '$disfraz' where Nombre_producto = 'Disfraz'");

echo "<script> alert('Actualizado correctamente a la Base de datos');window.location= 'almacen.php' </script>" ; 

}

 // Espada

 if(isset($_POST['precio4'])){

$espada = $_POST["espada"];

   
   $udpate_espada = mysqli_query($conn, "UPDATE productos SET precios = '$espada' where Nombre_producto = 'Espada'");
     
   echo "<script> alert('Actualizado correctamente a la Base de datos');window.location= 'almacen.php' </script>" ; 

  }
 

  // Garfio

  if(isset($_POST['precio2'])){

    $garfio = $_POST["garfio"];

      
      $update_garfio = mysqli_query($conn, "UPDATE productos SET precios = '$garfio' where Nombre_producto = 'Garfio'");
     
     
      echo "<script> alert('Actualizado correctamente a la Base de datos');window.location= 'almacen.php' </script>" ;  
    
  
  }

    else{

 echo "<script> alert('Algo salio mal');window.location= 'unidades.php' </script>" ;  
    

    }

?>