<?php

require('../LOGIN/conexion.php');

$espada = $_POST["espada"];


       // Espada

 $queryespada = mysqli_query($conn, "SELECT SUM(Unidades + $espada) as 'Unidades' from productos WHERE Nombre_producto = 'Espada'");

 $a_espada =$queryespada ->fetch_array()['Unidades'] ?? '';
   
   $udpate_espada = mysqli_query($conn, "UPDATE productos SET Unidades = $a_espada where Nombre_producto = 'Espada'");
       

    echo "<script> alert('Añadido correctamente a la Base de datos');window.location= 'almacen.php' </script>" ;  




    if(!$conn){
        echo"Error en la conexion con el servidor, no se inserto";
        }  


?>