<?php

session_start(); 

require('../LOGIN/conexion.php');

$user =  $_SESSION["usuario"];

$id_productos = $_POST["id"];

$resultado_nombre = mysqli_query($conn, "SELECT nombre from clientes where usuario='$user'");

$resultado_apellidos = mysqli_query($conn, "SELECT apellidos from clientes where usuario='$user'");

$resultado_direccion = mysqli_query($conn, "SELECT direccion from clientes where usuario='$user'");

$resultado_producto_nombre = mysqli_query($conn, "SELECT Nombre_producto from productos where id_productos = '$id_productos'");

$resultado_precio = mysqli_query($conn, "SELECT precios from productos where id_productos = '$id_productos'");

$row_nombre = $resultado_nombre->fetch_array()['nombre'] ?? '';

$row_apellidos = $resultado_apellidos->fetch_array()['apellidos'] ?? '';

$row_direccion = $resultado_direccion->fetch_array()['direccion'] ?? '';

$row_nombre_producto = $resultado_producto_nombre->fetch_array()['Nombre_producto'] ?? '';

$row_precio = $resultado_precio->fetch_array()['precios'] ?? '';


 if (isset($_POST['compra'])) 
{

// Insert de producto en la tabla pedidos

$insertargafio = mysqli_query($conn, "INSERT INTO pedidos VALUES ('$user', '$row_nombre', '$row_apellidos', '$row_direccion', '$row_nombre_producto', '$row_precio', '$id_productos', NULL)");

echo "<script> alert('Articulo ya tramitado');window.location= '../COMPRA/compra_cliente.php'</script>";

 }




?>
