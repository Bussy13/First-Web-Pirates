<?php

// Inciamos Sesion
session_start(); 

require('../LOGIN/conexion.php');

$id_productos = $_POST["id_productos"];

$resultado_producto_nombre = mysqli_query($conn, "SELECT Nombre_producto from productos where id_productos = '$id_productos'");

$resultado_precio = mysqli_query($conn, "SELECT precios from productos where id_productos = '$id_productos'");

$obtener_id = mysqli_query($conn, "SELECT id_productos from productos where id_productos = '$id_productos'");

$row_nombre_producto = $resultado_producto_nombre->fetch_array()['Nombre_producto'] ?? '';

$row_precio = $resultado_precio->fetch_array()['precios'] ?? '';

$row_id = $obtener_id->fetch_array()['id_productos'] ?? '';



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Link Boostrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Icono -->
    <link rel="icon" href="../Imagenes/favicon.jpg" type="image/x-icon">
    <!-- Link de mi CSS -->
    <link rel="stylesheet" href="caja.css">
    <title>The Pirates</title>
</head>

<body class="bg-bar">
<form action="validacion.php" method="post">
    <div class="container bg-light bordes mt-5">
        <form class="row g-3 needs-validation" novalidate>
            <div class="container justify-content-center d-flex pt-3">
                <p class="h1 fw-bold titulos">Datos de la Tarjeta</p>
            </div>
            <!-- Titular -->
            <div class="col-12">
                <label for="validationCustom01" class="form-label fw-bold">Titulo de la tarjeta</label>
                <input type="text" class="form-control w-75" id="validationCustom01" onkeydown="return /[a-z, ]/i.test(event.key)" required>
                <div class="invalid-feedback">
                Escriba su nombre
                </div>
            </div>
             <!-- Numero -->
            <div class="col-12">
                <label for="validationCustom02" class="form-label fw-bold">Numero de la Tarjeta</label>
                <input type="text" class="form-control w-75" id="validationCustom02" minlength="13" maxlength="18" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" required>
                <div class="invalid-feedback">
                    Repitalo, por favor
                </div>
            </div>
            <!-- Caducidad -->
            <div class="col-12">
                <label for="validationCustomUsername" class="form-label fw-bold">Caducidad</label>
                <div class="input-group has-validation w-50">
                    <input type="text" class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" minlength="4" maxlength="4" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" required>
                    <div class="invalid-feedback">
                        Ponga el valor adecuado, xx/xx
                    </div>
                </div>
            </div>
             <!-- CVV -->
            <div class="col-12">
                <label for="validationCustom03" class="form-label fw-bold">CVV</label>
                <input type="text" class="form-control w-25" id="validationCustom03" minlength="3" maxlength="3" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" required>
                <div class="invalid-feedback">
                   Ponga el numero de valor correspondiente, XXX
                </div>
            </div>
            <!-- Condiciones -->
             <div class="col-12">
                <div class="form-check mt-3">
                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                    <label class="form-check-label fw-bold" for="invalidCheck">
                        Acepto las condiciones de privacidad de esta web
                    </label>
                    <div class="invalid-feedback">
                       Deberas estar de acuerdo para continuar
                    </div>
                </div>
            </div>
            <!-- Hr [1]-->
            <div class="container w-75">
                   <hr> 
            </div>
            <!-- Metodos de pago -->
            <div class="col-12 mt-5">
                  <p class="h1 fw-bold titulos text-decoration-underline">Metodos de pago</p>
            </div>
            <div class="col-12 justify-content-center d-flex mt-5">
            <div class="form-check">
              <input id="credit" name="paymentMethod" type="radio" class="form-check-input" checked required>
              <label class="form-check-label fw-bold" for="credit">Credito</label>
            </div>
            <div class="form-check ms-5">
              <input id="debit" name="paymentMethod" type="radio" class="form-check-input" required>
              <label class="form-check-label fw-bold" for="debit">Debito</label>
            </div>
            <div class="form-check ms-5">
              <input id="paypal" name="paymentMethod" type="radio" class="form-check-input" required>
              <label class="form-check-label fw-bold" for="paypal">PayPal</label>
            </div>
          </div>
             <!-- Hr [3]] -->
             <div class="container w-50 mt-3">
                   <hr> 
            </div>
            <!-- Info de pago -->
            <div class="container mt-5 pt-5  w-25">
    <div class="row">
           <!-- Producto -->
        <div class="col-lg-6 col-md-6 col-sm-12 fst-italic h5 fw-bold">
            Articulo:
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12">
        <?php echo $row_nombre_producto ?>
        <!-- Imagenes? -->
        </div>
    </div>
</div>
  <!-- Hr [3]] -->
  <div class="container w-25">
                   <hr> 
            </div>
            <!-- Precio -->
            <div class="container mt-2  w-25">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 fst-italic h5 fw-bold">
        Pago de:
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12">
        <?php echo $row_precio ?>
        </div>
    </div>
                      <!-- Comprar -->
                      <div class="col-12 justify-content-center d-flex mt-5 pt-2">
            <a href="validacion.php"">
            <input type="hidden" value="<?php echo $row_id ?>" name="id">
                <button class="btn btn-outline-success mx-auto btn-lg" type="submit" name="compra">
                   Comprar
                </button>
            </a>
        </div>
          <!-- Hr [3]] -->
          <div class="container w-50 pt-5">
            </div>
</div>
            </div>
          </form>
        </div>
        <div class="container pt-5"></div>
    </div>
    <!-- Link Java Boostrap -->
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
 
   <!-- Script de alerta -->
   <script>
    var resultado = window.confirm('Articulo añadido, procediendo con la compra');
    </script>

   <!-- Validacion de Boostrap -->
    <script>
    (function() {
        'use strict'

        var forms = document.querySelectorAll('.needs-validation')


        Array.prototype.slice.call(forms)
            .forEach(function(form) {
                form.addEventListener('submit', function(event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
    })()
    </script>
    



    
</body>
</html>
