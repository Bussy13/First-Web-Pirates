<?php
//Inlcuir el archivo de conexion con la Base de datos
include ("../LOGIN/conexion.php");
include ("../REGISTRO/registro.php");
include ("../COMPRA/compra_cliente.php")

//Creo dos variables para el usario y contraseña del name="" en el form


 


//iniciamos sesión




?>

