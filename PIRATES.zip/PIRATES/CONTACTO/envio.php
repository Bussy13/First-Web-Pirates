<?php

session_start(); 

$para      = 'yoel.urquijo@telefonica.net';
$Nombre   = $_POST['usuario'];
$motivo    =  $_POST['motivo'];
$texto =  $_POST['texto'];
$cabeceras = 'From: yoelurquijo13@gmail.com' . "\r\n" .
            'Reply-To: yoelurquijo13@gmail.com' . "\r\n" .
            'X-Mailer: PHP/' . phpversion(); 

mail($para, $Nombre, $motivo, $texto, $cabeceras);

echo "<script> alert('Mensaje enviado correctamente.');window.location= 'contacto.php' </script>";

?>
