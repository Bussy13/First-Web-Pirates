<?php

session_start(); 


include ('../LOGIN/conexion.php');

$para      = 'yoel.pirates@gmail.com';
$Nombre   = $_POST['usuario'];
$correo = $_POST['correo'];
$texto =  $_POST['texto'];
$cabeceras = 'From: yoel.pirates@gmail.com' . "\r\n" .
            'Reply-To: yoel.pirates@gmail.com' . "\r\n" .
            'X-Mailer: PHP/' . phpversion();
            
            
$queries = mysqli_query($conn, "SELECT id FROM clientes where usuario='$Nombre' AND correo='$correo'");

$a = mysqli_num_rows($queries);



if($a == 1){

    echo 'correcto x2';

 mail($para, $Nombre, $texto, $cabeceras);


echo "<script> alert('Mensaje enviado correctamente.');window.location= 'contacto.php' </script>";

}else{


    echo"<script> alert('No se pudo enviar el mensaje');window.location= 'contacto.php' </script>";
}



?>
