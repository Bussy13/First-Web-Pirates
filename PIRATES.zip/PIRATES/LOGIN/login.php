<?php

//Inlcuir el archivo de conexion con la Base de datos
include ("conexion.php");
//Creo dos variables para el usario y contraseña del name="" en el form
$user = $_POST["usuario"];
$clave  = $_POST["contraseña"];

//Para iniciar sesión

//Declaramos dos variables y  mysqli_query nos permite ejecutar la query en la base de datos

$trabajadores = mysqli_query($conn, "SELECT id_empleados FROM empleados WHERE nombre ='$user'");

$tienda = mysqli_query($conn, "SELECT Puesto FROM empleados WHERE nombre ='$user' and Puesto='Tienda'");

$soporte = mysqli_query($conn, "SELECT Puesto FROM empleados WHERE nombre ='$user' and Puesto='Soporte'");

$clientes = mysqli_query($conn, "SELECT id FROM clientes WHERE usuario ='$user'");


$a      =mysqli_num_rows($trabajadores);

$b      =mysqli_num_rows($clientes);

$a_Tienda  =mysqli_num_rows($tienda);

$a_soporte =mysqli_num_rows($soporte);


//Acceso para Tienda

if($a == 1 and $a_Tienda ==1){

    $aa = mysqli_query($conn, "SELECT contraseña FROM empleados WHERE nombre ='$user'");

	$hash_empleado =$aa ->fetch_array()['contraseña'] ?? '';

	$clavecorrecta = password_verify($clave, $hash_empleado);

	
    //A traves de este if comprobaremos si la contraseña y el usuario pertenecen    

if ($a == 1 and password_verify($clave, $hash_empleado) == 1){

  
	echo "<script>window.location= '../T_tienda/t_tienda.php' </script>";

}
else{

	echo "<script> alert('Usuario o contraseña incorrecto.');window.location= 'login.html' </script>";
}


}

//Acceso para soporte

if($a == 1 and $a_soporte ==1){

    $aa = mysqli_query($conn, "SELECT contraseña FROM empleados WHERE nombre ='$user'");

	$hash_empleado =$aa ->fetch_array()['contraseña'] ?? '';

	
    //A traves de este if comprobaremos si la contraseña y el usuario pertenecen    

if (password_verify($clave, $hash_empleado) == 1 and $a == 1){

	echo "<script>window.location= '../T_soporte/T_soporte.php' </script>";

}
else{

	echo "<script> alert('Usuario o contraseña incorrecto.');window.location= 'login.html' </script>";
}


}

if($b == 1){

    $bb = mysqli_query($conn, "SELECT contraseña FROM clientes WHERE usuario ='$user'");

	$hash_clientes =$bb ->fetch_array()['contraseña'] ?? '';

	
    //A traves de este if comprobaremos si la contraseña y el usuario pertenecen    

if (password_verify($clave, $hash_clientes) == 1 and $b == 1) {

	echo "<script>window.location= '../Clientes/clientes.php' </script>";

}else{ 

	echo "<script> alert('Usuario o contraseña incorrecto.');window.location= 'login.html' </script>";
}


    
}

else{

	
	echo "<script> alert('Usuario o contraseña incorrecto.');window.location= 'login.html' </script>";
}

//Iniciar sesion

session_start();

$_SESSION["usuario"] = $user;

?>

