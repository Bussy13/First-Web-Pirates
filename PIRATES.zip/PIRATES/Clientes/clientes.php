<?php

// Inciamos Sesion

session_start(); 

if (!isset($_SESSION["usuario"])) {
    
    echo "<script> alert('Su sesion expiro');window.location= '../index.html' </script>";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Link Boostrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Links Iconos -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <!-- Link cdn.js -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css" integrity="sha512-UTNP5BXLIptsaj5WdKFrkFov94lDx+eBvbKyoe1YAfjeRPC+gT5kyZ10kOHCfNZqEui1sxmqvodNUx3KbuYI/A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css" integrity="sha512-OTcub78R3msOCtY3Tc6FzeDJ8N9qvQn1Ph49ou13xgA9VsH9+LRxoFU6EqLhW4+PKRfU+/HReXmSZXHEkpYoOA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Transiciones Libreria Imagens -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Readex+Pro&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- Personal CSS -->
    <link rel="stylesheet" href="clientes.css">
    <!-- My Icon -->
    <link rel="icon" href="../Imagenes/favicon.jpg" type="image/x-icon">
    <title>The Pirates</title>
</head>

<body class="bg-fondo">
    <!-- inicio -->
    <header>
                <!-- Inicio de log out -->
                <div class="container pt-5">
        <div class="dropdown">
  <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
  <p class="text-light"><img src="../Imagenes/usuario.png" class="limite"><?php echo $_SESSION["usuario"]; ?></p>
  </button>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="../CERRAR/cerrar.php">Cerrar sesion</a></li>
  </ul>
</div>
        </div>
        <!-- Fin de log out -->
        <div class="container-fluid mt-5 pt-1">
            <div class="container ">
                <!-- Maquina de escribir -->
                <div id="welcome-section">
                    <div class="hero mt-5 pt-5">
                        <h1 class="txt-type" data-wait="1000" data-words='["Bienvenido!", "<?php echo $_SESSION["usuario"]; ?>", "Este es el panel de control"]'></h1>
                    </div>
                </div>
    </header>
<!-- Aplicaciones -->
<section>
<div class="container-fluid mt-5 pt-5 d-flex justify-content-center">
    <div class="row">
        <!-- home -->
        <div class="col-lg-6 col-md-12 col-sm-12">
        <a href="../Home/home.php" class="enlaces texto">Home</a>
        </div>
           <!-- Tienda -->
        <div class="col-lg-6 col-md-12 col-sm-12"">
        <a href="../EQUIPAMIENTOS/equipamentos.php" class="enlaces">Tienda</a>
        </div>
    </div>
    </div>
    <!-- Segunda Parte -->
    <div class="container-fluid mt-4 d-flex justify-content-center">
    <div class="row">
        <!-- Office -->
        <div class="col-lg-6 col-md-12 col-sm-12"">
        <a href="" class="enlaces">Office</a>
        </div>
           <!-- Fotos -->
        <div class="col-lg-6 col-md-12 col-sm-12"">
        <a href="" class="enlaces">Fotos</a>
        </div>
    </div>
    </div>
    <div class="container mt-4 d-flex justify-content-center">
    <div class="row">
    <a href="../CONTACTO/contacto.html" class="enlaces">Contacto</a>
</div>
    </div>
</section>
    <!-- Espacio -->
    <div class="container w-75 pt-5 mt-5"></div>
    <!-- Hr linea blanca -->
    <div class="container w-75">
        <hr class="text-light">
    </div>
    <!-- Footer -->
    <footer>
        <!-- Footer  -->
        <div class="container-fluid">
            <p class="text-center text-light fst-italic fw-bold pt-3 texto">Copyright &copy; <script>
                document.write(new Date().getFullYear())
                </script> Pirates SL Tiene todos los derechos reservados.</p>
    </footer>
    <!--  Hr linea blanca  -->
    <div class="container w-25 mt-4">
        <hr class="text-light">
    </div>
    <!-- Espacio FINAL -->
    <div class="container w-75 pt-4"></div>
    <!-- LINKS [Parte de Java]-->
    <!-- libreria Java -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Libreria AOS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <!-- Link para lo del menu del color -->
    <script src="./Bootstrap 5 - Transparent Navbar_files/bootstrap.bundle.min.js"></script>
    <!-- SCRIPTS -->
      <!-- Script de alerta -->
      <script>
        var resultado = window.confirm('Consejo!! Los logos del pirata te llevan al HOME, es decir, esta pagina');
        </script>
            <!-- Maquina de Escribir [1] -->
    <script>
    class TypeWritter {
        constructor(txtElement, words, wait = 1000) {
            this.txtElement = txtElement;
            this.words = words;
            this.txt = '';
            this.wordIndex = 0;
            this.wait = parseInt(wait, 10);
            this.type();
            this.isDeleting = false;
        }
        type() {
            const current = this.wordIndex % this.words.length;
            const fullTxt = this.words[current];
            if (this.isDeleting) {

                this.txt = fullTxt.substring(0, this.txt.length - 1);
            } else {

                this.txt = fullTxt.substring(0, this.txt.length + 1);
            }
            this.txtElement.innerHTML = `<span class="txt">${this.txt}</span>`;
            // Velocidad de 2 segundos
            let typeSpeed = 200;
            if (this.isDeleting) {
                typeSpeed /= 2;
            }


            if (!this.isDeleting && this.txt === fullTxt) {
                // Pausa al Final
                typeSpeed = this.wait;
                this.isDeleting = true;
            } else if (this.isDeleting && this.txt === '') {
                this.isDeleting = false;
                // Siguiente palabra
                this.wordIndex++;

                typeSpeed = 300;
            }
            setTimeout(() => this.type(), typeSpeed); //
        }
    }


    document.addEventListener('DOMContentLoaded', init);

    function init() {
        const txtElement = document.querySelector('.txt-type');
        const words = JSON.parse(txtElement.getAttribute('data-words'));
        const wait = txtElement.getAttribute('data-wait');
        new TypeWritter(txtElement, words, wait);
    }
    </script>
    <!-- AOS -->
    <script>
    AOS.init();
    </script>
</body>

</html>