<?php
// Inciamos Sesion

session_start(); 
require('../LOGIN/conexion.php');

$resultado_precio = mysqli_query($conn, "SELECT precios from productos where id_productos = '3'");

$row_precio = $resultado_precio->fetch_array()['precios'] ?? '';


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Link Boostrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Link Css -->
    <link rel="stylesheet" href="./disfraz.css">
    <!-- My Icon -->
    <link rel="icon" href="../Imagenes/favicon.jpg" type="image/x-icon">
    <title>The Pirates</title>
</head>

<body class="bg-blanco">
    <!-- Menu -->
    <header>
        <input class="menu-icon" type="checkbox" id="menu-icon" name="menu-icon" />
        <label for="menu-icon"></label>
        <nav class="nav">
            <ul class="pt-5">
                <li><img src="../Imagenes/1.png" class="img-fluid h-8 pb-3"></li>
                <li><a href="../Home/home.html">Home</a></li>
                <li><a href="../EQUIPAMIENTOS/equipamentos.html" class="site">Tienda</a></li>
                <li><a href="../LOGIN/login.html">Login</a></li>
                <li><a href="../REGISTRO/registro.html">Registro</a></li>
                <li><a href="../CONTACTO/contacto.html">Contacto</a></li>
            </ul>
        </nav>
    </header>
    <!-- Producto -->
    <div class="container-fluid pt-2 mt-5">
        <div class="container-fluid mt-5 pt-5">
            <div class="row">
                <div class="col-md-5 pt-4">
                    <img src="../Imagenes/disfraz.jpg" class="img-fluid rounded mx-auto d-block">
                </div>
                <div class="col-md-7 pt-4">
                    <p class="h2 text-center titulos fw-bold">'Traje Barba Negra'</p>
                    <div class="container mt-3">
                        <div class="row">
                            <div class="col-md-4 col-lg-2">
                                <p class="pt-4 fw-bold text-decoration-underline">Descripcion:</p>
                            </div>
                            <div class="col-md-8 col-lg-10">
                                <p class="pt-4">Sientete como un verdadero pirata vistiendo el autentico traje de Barba Roja
                                </p>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4 col-lg-2">
                                <p class="pt-4 fw-bold text-decoration-underline">Estado:</p>
                            </div>
                            <div class="col-md-8 col-lg-10">
                                <p class="pt-4">Sin usar</p>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4 col-lg-2">
                                <p class="pt-4 fw-bold text-decoration-underline">Valor:</p>
                            </div>
                            <div class="col-md-8 col-lg-10">
                                <p class="pt-4 fw-bold"><?php echo $row_precio; ?></p>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4 col-lg-2">
                                <p class="pt-4 fw-bold text-decoration-underline">Valoracion:</p>
                            </div>
                            <div class="col-md-8 col-lg-10">
                                <p class="pt-4">⭐️⭐️⭐️⭐️⭐️</p>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4 col-lg-2">
                                <p class="pt-4 fw-bold text-decoration-underline">Opiniones:</p>
                            </div>
                            <div class="col-md-8 col-lg-10">
                                <p class="pt-4">Se ajusta como un guante</p>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4 col-lg-2">
                                <p class="pt-4 fw-bold text-decoration-underline">Referencia:</p>
                            </div>
                            <div class="col-md-8 col-lg-10">
                                <p class="pt-4">6789354322988</p>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <form action="../CAJA/caja.php" method="post">
                    <!-- Input de envio  -->
                    <input type="hidden" name="id_productos" value="3">
                    <!-- Añadir a la cesta -->
                    <div class="container d-flex justify-content-center pt-2">
                        <div class="btn-groupbtn-group-lg">
                            <a href="../CAJA/caja.php">
                        <button type="submit" class=" btn btn-outline-info">
                                Añadir a la cesta
                        </button>
                        </a>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Espacio -->
    <section>
        <div class="container mt-4"></div>
    </section>
    <!-- libreria Java -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>
</html>