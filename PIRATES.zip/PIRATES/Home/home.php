<?php

// Inciamos Sesion

session_start(); 

if (!isset($_SESSION["usuario"])) {
    
    echo "<script> alert('Su sesion expiro');window.location= '../index.html' </script>";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Link Boostrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Links Iconos -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <!-- Link cdn.js -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css" integrity="sha512-UTNP5BXLIptsaj5WdKFrkFov94lDx+eBvbKyoe1YAfjeRPC+gT5kyZ10kOHCfNZqEui1sxmqvodNUx3KbuYI/A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css" integrity="sha512-OTcub78R3msOCtY3Tc6FzeDJ8N9qvQn1Ph49ou13xgA9VsH9+LRxoFU6EqLhW4+PKRfU+/HReXmSZXHEkpYoOA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Transiciones Libreria Imagens -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Readex+Pro&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- Personal CSS -->
    <link rel="stylesheet" href="home.css">
    <!-- My Icon -->
    <link rel="icon" href="../Imagenes/favicon.jpg" type="image/x-icon">
    <title>The Pirates</title>
</head>

<body class="bg-fondo">
    <!-- Menu -->
    <header>
        <input class="menu-icon" type="checkbox" id="menu-icon" name="menu-icon" />
        <label for="menu-icon"></label>
        <nav class="nav">
            <ul class="pt-5">
                <li><a href="../Clientes/clientes.php"><img src="../Imagenes/1.png" class="img-fluid h-8 pb-3"></a></li>
                <li><a href="home.php" class="site">Home</a></li>
                <li><a href="../EQUIPAMIENTOS/equipamentos.php">Tienda</a></li>
                <li><a href="">Fotos</a></li>
                <li><a href="">Office</a></li>
                <li><a href="../CONTACTO/contacto.html">Contacto</a></li>
            </ul>
        </nav>
    </header>
    <!-- inicio -->
    <main>
             <!-- Inicio de log out -->
        <div class="container pt-5">
        <div class="dropdown">
  <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
  <p class="text-light"><img src="../Imagenes/usuario.png" class="limite"><?php echo $_SESSION["usuario"]; ?></p>
  </button>
  <ul class="dropdown-menu">
  <li><a class="dropdown-item" href="../Clientes/clientes.php">Panel de control</a></li>
    <li><a class="dropdown-item text-ligth" href="../CERRAR/cerrar.php">Cerrar sesion</a></li>
  </ul>
</div>
        </div>
        <!-- Fin de log out -->
        <div class="container-fluid mt-5 pt-1">
            <div class="container ">
                <!-- Maquina de escribir -->
                <div id="welcome-section">
                    <div class="hero mt-5 pt-5">
                        <h1 class="txt-type" data-wait="1000" data-words='["Hola Pirata!", "Espero que disfrutes la navegacion", "Y de las batallas que te esperan!"]'></h1>
                    </div>
                </div>
                <!-- Imagen de Logo -->
                <div class="container d-flex justify-content-center pt-5">
                    <a href="home.html"><img src="../Imagenes/1.png" data-aos="flip-up" class="img-fluid" data-aos-easing="linear" data-aos-duration="2000"></a>
                </div>
            </div>
        </div>
    </main>
    <!-- Boton con accion -->
    <article>
        <div class="container-fluid mt-5"></div>
        <div class="container-fluid mt-5 pt-5 center">
            <button id=button class="button center fw-bold">CLICAME!</button>
            <p id="type" class="text-danger titulos h2 pt-5"></p>
        </div>
        <!-- Espacio -->
        <div class="container w-75 pt-5 mt-5"></div>
        <!-- Animacion Imagenes// Historia -->
        <div class="container mt-5 pt-5">
            <!-- Parte 1/5 -->
            <div class="row">
                <div class="col-md-12 col-lg-6">
                    <div class="container" data-aos="fade-up" data-aos-duration="1500">
                        <img src="../Imagenes/3.jpg" class="img-fluid marcos desenfoque no-desenfoque">
                    </div>
                </div>
                <div class="col-md-12 col-lg-6">
                    <div class="container pt-3" data-aos="zoom-in" data-aos-duration="3000">
                        <p class="h2 titulos text-center text-light text-decoration-underline desenfoque no-desenfoque">"La gran lucha en el frente"</p>
                        <div class="container">
                            <p class="text-center text-light pt-5">Tras ser un corsario al servicio del Imperio británico, Barbanegra se convirtió en pirata y dio sus primeros golpes con otro famoso pirata, <a href="https://es.wikipedia.org/wiki/Benjamin_Hornigold" class="text-danger">Benjamin Hornigold</a>
                                <br>
                                <br>
                                Su aspecto y mirada demoníaca hicieron de Barbanegra el terror de los mares. En cada abordaje encendía unas mechas de cañón que adornaban su barba.
                                <br>
                                <br>
                                La hazaña que hizo célebre a Barbanegra fue perpetrada en la base naval de San Vicente, en las islas de Barlovento, donde apresó a la nave Great Allen, que transportaba un valioso cargamento. Tras la escaramuza asesinó a la tripulación e hizo quemar el barco.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Parte 2/5 -->
        <div class="container justify-content-center d-flex h-99 pt-5" data-aos="fade-right" data-aos-duration="1500">
            <img src="../Imagenes/2.jpg" class="img-fluid marcos  desenfoque no-desenfoque">
        </div>
        <!-- Parte 3/5 -->
        <div class="container justify-content-left d-flex pt-3" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1500">
            <p class="h2 titulos text-decoration-underline pt-3"><a href="https://es.wikipedia.org/wiki/Venganza_de_la_Reina_Ana" class="text-danger hover">"Venganza de la reina Ana"</a></p>
        </div>
        <!-- Parte 4/5 -->
        <div class="container justify-content-center d-flex pt-5 mt-3 h-99" data-aos="flip-left" data-aos-duration="3000">
            <img src="../Imagenes/5.jpg" class="img-fluid  desenfoque no-desenfoque">
        </div>
        <!-- Parte 5/5 -->
        <div class="container justify-content-center d-flex pt-5" data-aos="flip-up" data-aos-duration="1500">
            <p class="text-center h1 titulos rey">"El rey de los cinco grandes Oceános"</p>
        </div>
    </article>
    <!-- Mapa -->
    <section>
        <div class="container mt-5 pt-5">
            <div class="container mt-5 pt-5" id="mapa">
                <p class="h2 text-light text-center titulos"><span class="text-decoration-underline">¿Estamos lejos o cerca?</span> , <span class="text-warning ps-3 pe-2 text-decoration-underline">Aquí</span> lo puedes ver!!</p>
            </div>
            <div class="container d-flex justify-content-center pt-5">
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12144.017759916967!2d-3.6883337!3d40.4530387!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xa8fff6d26e2b1988!2sEstadio%20Santiago%20Bernab%C3%A9u!5e0!3m2!1ses!2ses!4v1650398001499!5m2!1ses!2ses" class="maps" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </section>
    <!-- Hr linea Blanca -->
    <div class="container w-25  mt-5 pt-5">
        <hr class="text-light">
    </div>
    <!-- Espacio -->
    <div class="container w-75 mt-5"></div>
    <!-- Carrousel con Slide -->
    <section>
        <div class="owl-container mt-5 px-5">
            <p class="h2 text-light text-center text-decoration-underline mt-5 titulos">Siguenos para no perderte nada</p>
            <div class="container w-50 pt-5">
                <div class="owl-carousel owl-theme">
                    <div class="item d-flex justify-content-center">
                        <!-- YOUTUBE -->
                        <a href="https://www.youtube.com/channel/UC5z0qnm6NluzDRUvfuXIEig/videos"><svg xmlns="http://www.w3.org/2000/svg" class="iconos" fill="currentColor" class="bi bi-youtube" viewBox="0 0 16 16">
                                <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.108-.082 2.06l-.008.105-.009.104c-.05.572-.124 1.14-.235 1.558a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c.487-.13 1.544-.21 2.654-.26l.17-.007.172-.006.086-.003.171-.007A99.788 99.788 0 0 1 7.858 2h.193zM6.4 5.209v4.818l4.157-2.408L6.4 5.209z" />
                            </svg></a>
                    </div>
                    <!-- TWITTER -->
                    <div class="item d-flex justify-content-center"><a href="https://twitter.com/?lang=es"><svg xmlns="http://www.w3.org/2000/svg" class="iconos" fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
                                <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z" />
                            </svg></a></div>
                    <!-- LINKEDIN -->
                    <div class="item d-flex justify-content-center"><a href="https://www.linkedin.com"><svg xmlns="http://www.w3.org/2000/svg" class="iconos" fill="currentColor" class="bi bi-linkedin" viewBox="0 0 16 16">
                                <path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854V1.146zm4.943 12.248V6.169H2.542v7.225h2.401zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248-.822 0-1.359.54-1.359 1.248 0 .694.521 1.248 1.327 1.248h.016zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016a5.54 5.54 0 0 1 .016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225h2.4z" />
                            </svg></a></div>
                    <!-- Github -->
                    <div class="item d-flex justify-content-center"><a href="https://github.com/Bussy13?tab=projects"><svg xmlns="http://www.w3.org/2000/svg" class="iconos" fill="currentColor" class="bi bi-github" viewBox="0 0 16 16">
                                <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.012 8.012 0 0 0 16 8c0-4.42-3.58-8-8-8z" />
                            </svg></a></div>
                </div>
            </div>
    </section>
    <!-- Espacio -->
    <div class="container w-75 pt-5 mt-5"></div>
    <!-- Hr linea blanca -->
    <div class="container w-75">
        <hr class="text-light">
    </div>
    <!-- Footer -->
    <footer>
        <!-- Footer  -->
        <div class="container-fluid">
            <p class="text-center text-light fst-italic fw-bold pt-3 texto">Copyright &copy; <script>
                document.write(new Date().getFullYear())
                </script> Pirates SL Tiene todos los derechos reservados.</p>
    </footer>
    <!--  Hr linea blanca  -->
    <div class="container w-25 mt-4">
        <hr class="text-light">
    </div>
    <!-- Espacio FINAL -->
    <div class="container w-75 pt-4"></div>
    <!-- LINKS [Parte de Java]-->
    <!-- libreria Java -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Libreria AOS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <!-- Link para lo del menu del color -->
    <script src="./Bootstrap 5 - Transparent Navbar_files/bootstrap.bundle.min.js"></script>
    <!-- SCRIPTS -->
    <!-- Owl Carrousel -->
    <script type="text/javascript">
    $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 0,
        padding: 0,
        nav: true,
        autoplay: true,
        autoplayTimeout: 5000,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 4
            }
        }
    })
    </script>
    <!-- Maquina de Escribir [1] -->
    <script>
    class TypeWritter {
        constructor(txtElement, words, wait = 1000) {
            this.txtElement = txtElement;
            this.words = words;
            this.txt = '';
            this.wordIndex = 0;
            this.wait = parseInt(wait, 10);
            this.type();
            this.isDeleting = false;
        }
        type() {
            const current = this.wordIndex % this.words.length;
            const fullTxt = this.words[current];
            if (this.isDeleting) {

                this.txt = fullTxt.substring(0, this.txt.length - 1);
            } else {

                this.txt = fullTxt.substring(0, this.txt.length + 1);
            }
            this.txtElement.innerHTML = `<span class="txt">${this.txt}</span>`;
            // Velocidad de 2 segundos
            let typeSpeed = 200;
            if (this.isDeleting) {
                typeSpeed /= 2;
            }


            if (!this.isDeleting && this.txt === fullTxt) {
                // Pausa al Final
                typeSpeed = this.wait;
                this.isDeleting = true;
            } else if (this.isDeleting && this.txt === '') {
                this.isDeleting = false;
                // Siguiente palabra
                this.wordIndex++;

                typeSpeed = 300;
            }
            setTimeout(() => this.type(), typeSpeed); //
        }
    }


    document.addEventListener('DOMContentLoaded', init);

    function init() {
        const txtElement = document.querySelector('.txt-type');
        const words = JSON.parse(txtElement.getAttribute('data-words'));
        const wait = txtElement.getAttribute('data-wait');
        new TypeWritter(txtElement, words, wait);
    }
    </script>
    <!-- Maquina de Escribir [2] -->
    <script>
    var myText = 'La Historia del Temible Barba Negra...',

        i = 0,

        MyBtn = document.getElementById('button'),

        pause = document.getElementById('pause'),

        resume = document.getElementById('resume'),

        reset = document.getElementById('reset'),

        myP = document.getElementById('type'),

        typeWritter;

    MyBtn.onclick = function() {

        'use strict';

        return typeWritter = setInterval(function() {

            if (i >= myText.length) {

                clearInterval(typeWritter);

            } else {

                myP.textContent += myText[i];

                i += 1;

            }
        }, 100);

    };
    </script>
    <!-- AOS -->
    <script>
    AOS.init();
    </script>
</body>

</html>