<?php

// Inciamos Sesion
session_start(); 

session_destroy();

echo "<script> alert('Se cerro su sesion');window.location= '../index.html' </script>";

?>