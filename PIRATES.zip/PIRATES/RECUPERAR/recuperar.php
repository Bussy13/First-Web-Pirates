<?php
$para      = 'yoelurquijo13@gmail.com';
$correo    =  $_POST['correo'];
$nombre    =  $_POST['nombre'];
$mensaje   = $_POST['mensaje'];
$cabeceras = 'From: yoelurquijo13@gmail.com' . "\r\n" .
            'Reply-To: yoelurquijo13@gmail.com' . "\r\n" .
            'X-Mailer: PHP/' . phpversion(); 

mail($para, $correo, $nombre, $mensaje, $cabeceras);

echo "<script> alert('Mensaje enviado correctamente.');window.location= 'home.html' </script>";

?>
