<?php
$para      = 'yoelurquijo13@gmail.com';
$nombres    =  $_POST['nombre'];
$email    =  $_POST['correo'];









$cabeceras = 'From: yoelurquijo13@gmail.com' . "\r\n" .
            'Reply-To: yoelurquijo13@gmail.com' . "\r\n" .
            'X-Mailer: PHP/' . phpversion(); 

// mail($para, $correo, $nombre, $mensaje, $cabeceras);

// echo "<script> alert('Mensaje enviado correctamente.');window.location= 'home.html' </script>";


?>
