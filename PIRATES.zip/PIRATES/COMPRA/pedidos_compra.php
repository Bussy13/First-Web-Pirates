<?php

// Inciamos Sesion

require('../LOGIN/conexion.php');

$usuario =  $_SESSION["usuario"];

$Nombre = mysqli_query($conn, "SELECT Nombre from pedidos where usuario='$usuario'");

$p_nombre =$Nombre->fetch_array()['Nombre'] ?? '';

$Apellidos = mysqli_query($conn, "SELECT apellidos from pedidos where usuario='$usuario'");

$p_apellidos =$Apellidos->fetch_array()['apellidos'] ?? '';


$direccion = mysqli_query($conn, "SELECT direccion from pedidos where usuario='$usuario'");

$p_direccion =$direccion->fetch_array()['direccion'] ?? '';

$producto = mysqli_query($conn, "SELECT producto from pedidos where usuario='$usuario'");

$p_producto =$producto ->fetch_array()['producto'] ?? '';

$precio = mysqli_query($conn, "SELECT precio from pedidos where usuario='$usuario'");

$p_precio =$precio ->fetch_array()['precio'] ?? '';

$id_pedido = mysqli_query($conn, "SELECT id_pedido from pedidos where usuario='$usuario'");

$id_pedidos =$id_pedido ->fetch_array()['id_pedido'] ?? '';

$fecha =mysqli_query($conn, "SELECT DATE(NOW()) AS 'Fecha actual'");

$fecha_actual =$fecha->fetch_array()['Fecha actual'] ?? '';




?>