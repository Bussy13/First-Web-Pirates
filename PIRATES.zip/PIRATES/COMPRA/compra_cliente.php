<?php

// Inciamos Sesion

session_start(); 

if (!isset($_SESSION["usuario"])) {
    
    echo "<script> alert('Su sesion expiro');window.location= '../index.html' </script>";
}
require('pedidos_compra.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Link Boostrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Link mi CSS -->
       <link rel="stylesheet" href="compra.css">
    <!-- Icono -->
    <link rel="icon" href="../Imagenes/favicon.jpg" type="image/x-icon">
       <title>The Pirates</title>
</head>
<body class="bg-negro">
  <head>     
  <div class="container-fluid pt-5 d-flex justify-content-center">
    <img src="../Imagenes/1.png" class="img-fluid h-3 ">
 </div>
  </head>
        <!-- Factura -->
        <div class="container-fluid pt-5 mt-5">
          <div class="container  bg-azul d-flex justify-content-center p-3">
          <h1 class="fst-italic text-light">Factura de <span class="text-danger"><?php echo $_SESSION["usuario"]; ?></span> </h1>
          </div>
<section id="factura1" class="container d-flex justify-content-center pt-4 bg-light">
  <div class="container ">
      <!-- Contenido -->
<div class="container">
    <div class="row">
        <!-- Nombre -->
        <div class="col-lg-2 bg-light pt-4">
<div class=" d-flex justify-content-center">
<h5 class="fw-bold text-dark">Nombre: <span class="text-success"><?php echo $p_nombre; ?></span></h5>
</div>
</div>
<!-- Apellidos -->
 <div class="col-lg-2 bg-light pt-4">
<div class=" d-flex justify-content-center">
<h5 class="fw-bold text-dark">Apellidos: <span class="text-success"><?php echo $p_apellidos; ?></span></h5>
</div>
</div>
<!-- Direccion -->
<div class="col-lg-3 bg-light pt-4">
<div class=" d-flex justify-content-center">
<h5 class="fw-bold text-dark">Direccion: <span class="text-success fs-6"><?php echo $p_direccion; ?></span></h5>
</div>
</div>
<!-- Producto -->
<div class="col-lg-2 bg-light pt-4">
<div class=" d-flex justify-content-center">
<h5 class="fw-bold text-dark">Producto: <span class="text-success"><?php echo $p_producto; ?></span></h5>
</div>
</div>
<!-- Precio -->
<div class="col-lg-2 bg-light pt-4">
<div class=" d-flex justify-content-center">
<h5 class="fw-bold text-dark">Precio: <span class="text-success"><?php echo $p_precio; ?></span></h5>
</div>
</div>
</section>
<div class="container pt-5 d-flex justify-content-center bg-light">
<button onclick="facturar();" class="btn btn-outline-dark mb-5">Imprimir</button>
</div>
</body>
<!-- libreria Java -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- Scripts -->
<!-- Imprimir -->
<script>
function facturar(){
  //creando una ventana para ubicar el recibo
  var ventana = window.open('', 'PRINT', 'height=400,width=600');

  
  //insertando el html a imprimir
  var htmlrecibo = '<h2>Recibo de pago</h2><h1>Pirates SL</h1><h3>No. de pedido: <?php echo $id_pedidos; ?></h3><h3> Fecha: <?php echo $fecha_actual;?></h3>'; //este es el encabezado
  var htmlrecibo2 = '<img src="../Imagenes/1.png" class="img-fluid h-3">';
  
  //escribiendo
  ventana.document.write(htmlrecibo + document.getElementById("factura1").innerHTML+ htmlrecibo2);
  ventana.document.close(); //se debe cerrar el html
  ventana.print(); //ejecutando la funcion interna imprimir
}
</script>

</html>

